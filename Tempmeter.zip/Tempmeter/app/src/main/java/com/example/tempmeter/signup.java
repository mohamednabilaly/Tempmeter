package com.example.tempmeter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class signup extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private EditText Email;
    private EditText password;
    private EditText confermpassword;
    private Button signinbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
       firebaseAuth = FirebaseAuth.getInstance();


        //EditText username = (EditText) findViewById(R.id.Usernamfield);
        final EditText Email = (EditText) findViewById(R.id.Emailfield);
        final EditText password = (EditText) findViewById(R.id.Passwordfield);
        final EditText confermpassword = (EditText) findViewById(R.id.Passwordcfield);

       final String email = Email.getText().toString();
        final String pass = password.getText().toString();

        final Button signinbtn2 = (Button) findViewById(R.id.signupbtn);
        signinbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                 firebaseAuth.createUserWithEmailAndPassword(Email.getText().toString().trim(), password.getText().toString().trim()).addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isSuccessful()){
                            Toastmasg("Try again");

                        }else{
                           Toast.makeText(getApplicationContext(),"ana sha8al yala ",Toast.LENGTH_SHORT);
                            openpage();
                        }

                    }
                });




            }
        });

    }


    public void openpage(){
        Intent main = new Intent(signup.this, Loginpage.class);
        startActivity(main);
    }

    private void Toastmasg (String msg){
        Toast.makeText(this, msg, Toast.LENGTH_LONG);
    }

}
